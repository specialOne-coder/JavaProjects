/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Algo2emepartie;

import java.util.Scanner;

/**
 *
 * @author user01
 */
public class PARTIE2EXO1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner Sc=new Scanner (System.in);
    int taille;
        System.out.println("veuiller entrer la taille du tableau");
        taille=Sc.nextInt();
        int tab1[]=new int[taille];
        for(int i=0;i<tab1.length;i++){
            System.out.println("Entrer les les valeurs du tableau : tab["+i+"]=");
            tab1[i]=Sc.nextInt();
        }
        for(int i=0;i<taille;i++){
        System.out.println("VOICI la somme de ces valeurs");
        int somme;
        somme=tab1[i]+tab1[i];
            System.out.println(somme);
    }
      for(int i=0;i<tab1.length;i++){
        System.out.println("VOICI la MOYENNE de ces valeurs");
        double moyenne;
        moyenne=tab1[i]+tab1[i]/(taille);
            System.out.println(moyenne);  
       
      }
      for(int i=0;i<tab1.length;i++){
     if(tab1[i]>tab1[i]){
         System.out.println( "voici la plus grande valeur du tableau"+tab1[i]);
     }
      
      }
    }
}

