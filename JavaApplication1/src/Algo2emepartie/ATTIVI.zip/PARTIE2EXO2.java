/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Algo2emepartie;

import java.util.Scanner;

/**
 *
 * @author user01
 */
public class PARTIE2EXO2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner Sc=new Scanner(System.in);
    int l=5;
    int c=4;
    int tab[][]=new int [4][5];
    for(int i=0;i<l;i++){
        for(int j=0;j<c;j++){
        System.out.println("Veuiller entrer les donneés");
        tab[i][j]= Sc.nextInt();
    
        System.out.println(tab[i][j]);
    
    }  
}
}
}